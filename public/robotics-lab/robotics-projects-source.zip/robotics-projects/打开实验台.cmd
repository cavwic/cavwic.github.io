@echo off
title Cavwic Robotics Labs
powershell.exe -NoProfile -Command "Start-ScheduledTask -TaskName 'Cavwic-Astro-Preview'; $taskReady=$false; for($taskAttempt=0;$taskAttempt -lt 20;$taskAttempt++){try{$taskResponse=Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:43201/tools/robotics-lab' -TimeoutSec 2;if($taskResponse.StatusCode -eq 200){$taskReady=$true;break}}catch{};Start-Sleep -Milliseconds 500};if($taskReady){Start-Process 'http://127.0.0.1:43201/tools/robotics-lab'}else{Write-Host 'Local preview did not become ready. Check Cavwic-Astro-Preview.';exit 1}"
if errorlevel 1 pause
